Find the Forms Coding Challenge                                                      

Language Info

language: Python

version: Python 3.9.5

Commands

run: Type main.py in terminal to run script.

install dependencies: pip install -r requirements.txt

Feedback

Hello and thank you for giving me this opportunity. This was a challenging but fair learning experience and I enjoyed every second of it!
I strongly prefer this form of interviewing over the traditional "solve a hard leetcode problem in 30 min" form. This interview challenge can tell a lot about how a person 
codes in real life situations.




